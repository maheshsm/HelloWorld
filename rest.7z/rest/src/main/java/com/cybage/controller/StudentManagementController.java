package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.model.Student;
import com.cybage.service.IStudentService;
import com.cybage.service.StudentService;

@RestController
public class StudentManagementController 
{

	@Autowired
	IStudentService studentService;
	
	@RequestMapping(value = "/students/", method = RequestMethod.GET)
	public ResponseEntity<List<Student>> listAllUsers() 
	{
		List<Student> users = studentService.listStudent();

		return new ResponseEntity<List<Student>>(users, HttpStatus.OK);
	}

}













/*	  @RequestMapping(value = "/students/", method = RequestMethod.POST)
public ResponseEntity<Void> createUser(@RequestBody Student employee, UriComponentsBuilder ucBuilder) 
{
    System.out.println("Creating User " + employee.getFirstname());

    studentService.addStudent(employee);

    HttpHeaders headers = new HttpHeaders();
    return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
}

*/	  

/*
@RequestMapping(value = "/students", consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
public ResponseEntity<String> createEmployee(@RequestBody Student student) 
{
is.addStudent(student);
return new ResponseEntity<String>(HttpStatus.CREATED);
}

*/