package com.cybage.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cybage.model.Student;


public interface IStudentService 
{
	public Integer addStudent(Student student);
	public List<Student> listStudent() ;
}
