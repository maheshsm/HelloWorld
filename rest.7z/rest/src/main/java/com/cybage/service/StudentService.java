package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.dao.IStudentDao;
import com.cybage.dao.StudentDao;
import com.cybage.model.Student;

@Service("studentService")
@Transactional
public class StudentService implements IStudentService 
{
	@Autowired
	private IStudentDao personDAO;

	public StudentService()
	{
		System.out.println("In Service");
	}

	public Integer addStudent(Student student)
	{
		System.out.println("In Service . . ."+student.getCity());
		 return personDAO.addStudent(student);
	}
	
	public List<Student> listStudent() 
	{
		System.out.println("In List Service");
		
		return personDAO.listStudent();
	}
}
