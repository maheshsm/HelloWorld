package com.cybage.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.model.Student;

@Repository("personDAO")
public class StudentDao implements IStudentDao 
{
	@Autowired
	private SessionFactory sessionFactory;
	
	private Session session;
	
	public StudentDao()
	{
		System.out.println("In Dao Default constr . . .");
	}

	public Integer addStudent(Student student) 
	{
		Integer id = (Integer) sessionFactory.getCurrentSession().save(student);
		System.out.println("Object Saved");
		return id;	
	}
	
	public List<Student> listStudent() {
		session = sessionFactory.getCurrentSession();
		List<Student> personsList = session.createQuery("from Student").list();
		
		return personsList;
	}
}
