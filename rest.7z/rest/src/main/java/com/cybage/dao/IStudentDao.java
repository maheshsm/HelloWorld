package com.cybage.dao;

import java.util.List;

import com.cybage.model.Student;

public interface IStudentDao 
{
	
	public Integer addStudent(Student student);
	
	public List<Student> listStudent();
}
